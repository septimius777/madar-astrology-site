import { useState, type FormEvent } from "react";
import Reveal from "../ui/Reveal";
import { useParallax } from "../../hooks/useParallax";

/**
 * Ports the CONTACT section (the comet). NOTE: like the original site, this
 * form is front-end only — no email is actually sent. Wire the onSubmit
 * handler up to your real email/booking service of choice.
 */
export default function MedarContactSection() {
  const planetRef = useParallax<HTMLDivElement>(0.15);
  const [status, setStatus] = useState("");

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    // NOTE: demo only — wire this to your email/booking service of choice.
    setStatus("پیامت دریافت شد. به‌زودی پاسخ می‌دهیم.");
    e.currentTarget.reset();
  }

  return (
    <section id="contact" className="medar-section medar-contact">
      <div
        ref={planetRef}
        className="medar-planet medar-planet--comet"
        aria-hidden="true"
      />
      <div className="medar-container medar-contact__grid">
        <div className="medar-contact__intro">
          <Reveal as="p" className="medar-eyebrow">
            ☄ یک پیام بفرست
          </Reveal>
          <Reveal as="h2" className="medar-section-title">
            شروعِ گفت‌وگو
          </Reveal>
          <Reveal as="p">
            سؤالی درباره‌ی زایچه‌ات داری، یا می‌خواهی یک جلسه رزرو کنی؟ همین‌جا بنویس.
          </Reveal>
        </div>

        <Reveal as="form" className="medar-contact-form" onSubmit={handleSubmit}>
          <label>
            <span>نام</span>
            <input type="text" name="name" required autoComplete="name" />
          </label>
          <label>
            <span>ایمیل</span>
            <input type="email" name="email" required autoComplete="email" />
          </label>
          <label>
            <span>پیام</span>
            <textarea name="message" rows={4} required />
          </label>
          <button type="submit" className="medar-btn medar-btn--primary">
            ارسالِ پیام
          </button>
          <p className="medar-contact-form__status" aria-live="polite">
            {status}
          </p>
        </Reveal>
      </div>
    </section>
  );
}
