import { useRef, useState, type MouseEvent as ReactMouseEvent } from "react";
import {
  motion,
  useMotionValue,
  useSpring,
  useTransform,
  useReducedMotion,
} from "framer-motion";
import { ZODIAC, type ZodiacSign } from "../../data/zodiacData";
import Reveal from "../ui/Reveal";
import ConstellationGlyph from "../ui/ConstellationGlyph";

const gridVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.07, delayChildren: 0.05 },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 36, scale: 0.94 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 0.65, ease: [0.16, 1, 0.3, 1] },
  },
};

function ZodiacCard({ sign }: { sign: ZodiacSign }) {
  const prefersReducedMotion = useReducedMotion();
  const cardRef = useRef<HTMLDivElement>(null);
  const [hovered, setHovered] = useState(false);

  // Pointer position, normalized to -0.5..0.5 across the card.
  const mx = useMotionValue(0);
  const my = useMotionValue(0);

  const rotateX = useSpring(useTransform(my, [-0.5, 0.5], [8, -8]), {
    stiffness: 220,
    damping: 20,
  });
  const rotateY = useSpring(useTransform(mx, [-0.5, 0.5], [-8, 8]), {
    stiffness: 220,
    damping: 20,
  });
  const glowX = useTransform(mx, [-0.5, 0.5], ["15%", "85%"]);
  const glowY = useTransform(my, [-0.5, 0.5], ["15%", "85%"]);
  const glowBackground = useTransform(
    () =>
      `radial-gradient(200px circle at ${glowX.get()} ${glowY.get()}, rgba(230,200,119,.20), transparent 70%)`
  );

  function handleMouseMove(e: ReactMouseEvent<HTMLDivElement>) {
    if (prefersReducedMotion) return;
    const el = cardRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    mx.set((e.clientX - rect.left) / rect.width - 0.5);
    my.set((e.clientY - rect.top) / rect.height - 0.5);
  }

  function handleLeave() {
    mx.set(0);
    my.set(0);
    setHovered(false);
  }

  return (
    <motion.article
      ref={cardRef}
      variants={cardVariants}
      className="medar-zodiac-card"
      style={
        prefersReducedMotion
          ? undefined
          : { rotateX, rotateY, transformPerspective: 700 }
      }
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={handleLeave}
      whileHover={{ scale: 1.045, y: -6 }}
      transition={{ type: "spring", stiffness: 260, damping: 20 }}
    >
      {!prefersReducedMotion && (
        <motion.div
          className="medar-zodiac-card__glow"
          style={{ background: glowBackground, opacity: hovered ? 1 : 0 }}
          aria-hidden="true"
        />
      )}

      <ConstellationGlyph sign={sign} />

      <div>
        <motion.span
          className="medar-zodiac-card__symbol"
          animate={
            hovered && !prefersReducedMotion
              ? { scale: 1.25, rotate: 8 }
              : { scale: 1, rotate: 0 }
          }
          transition={{ type: "spring", stiffness: 300, damping: 12 }}
        >
          {sign.symbol}
        </motion.span>
        <h3>
          {sign.sign}{" "}
          <span style={{ color: "var(--medar-c-mist-dim)", fontWeight: 400 }}>
            ({sign.latin})
          </span>
        </h3>
      </div>
      <p className="medar-zodiac-card__month">
        ماه {sign.month} · عنصر {sign.element}
      </p>
      <p>{sign.short}</p>
    </motion.article>
  );
}

/** Ports the GALLERY section — the twelve-sign zodiac belt. */
export default function MedarGallerySection() {
  return (
    <section id="gallery" className="medar-section medar-gallery">
      <div className="medar-container">
        <Reveal as="p" className="medar-eyebrow">
          ✶ نوارِ منطقةالبروج — دوازده برج
        </Reveal>
        <Reveal as="h2" className="medar-section-title">
          دوازده صورتِ فلکی، دوازده مزاج
        </Reveal>
        <Reveal as="p" className="medar-section-lead">
          هر برج، یک ماهِ تقویم خورشیدی و یک الگوی ستاره‌ای دارد.
        </Reveal>

        <motion.div
          className="medar-zodiac-grid"
          variants={gridVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.15 }}
        >
          {ZODIAC.map((z) => (
            <ZodiacCard key={z.latin} sign={z} />
          ))}
        </motion.div>
      </div>
    </section>
  );
}