import { Routes, Route } from "react-router-dom";
// import RootPage from "./pages/RootPage";
// import HomePage from "./pages/HomePage";
import MedarPage from "./pages/MedarPage";
import SolarSystem from "./pages/SolarSystem";
import SignUp from "./pages/SignUp";
import Login from "./pages/Login";
// import SolarPage from "./pages/SolarPage";
// import Home from "./pages/Home";
export default function App() {
  return (
    <Routes>
      {/* <Route path="/" element={<RootPage />} />
      <Route path="/home" element={<Home />} />
      <Route path="/solarPage" element={<SolarPage />} />
      <Route path="/homepage" element={<HomePage />} /> */}
      <Route path="/medarpage" element={<MedarPage />} />
      <Route path="/signup" element={<SignUp />} />
      <Route path="/login" element={<Login />} />
      <Route path="/solarsystem" element={<SolarSystem />} />
    </Routes>
  );
}